# 华南理工大学研究生开题报告 LaTeX 版

根据上传的《研究生学位（毕业）论文开题报告2026.4.13.docx》转换。保留封面、七个正文板块、八个原始表格、填写要求、作者承诺、导师意见、审核签名及最后的定密审批表，个人信息和正文留空。

## 编译

上传完整压缩包到 Overleaf，主文件选择 `main.tex`，编译器设置为 **XeLaTeX**。本地使用含中文支持的 TeX Live 或 MiKTeX：

```bash
xelatex main.tex
xelatex main.tex
```

## 填写位置

- `metadata.tex`：姓名、导师、学号、院系、专业、中文和英文题目、关键词、日期与勾选框。内容会同步用于封面、摘要表及定密审批表。
- `sections/01-abstract.tex`：摘要，不超过800字。
- `sections/02-basis.tex`：立题依据。
- `sections/03-research-plan.tex`：研究方案。
- `sections/04-foundation.tex`：研究条件与基础。
- `sections/05-schedule.tex`：进度安排，保留原表的八个空白记录行；每行分别为起止时间、工作内容、备注。
- `sections/06-expected-results.tex`：预期成果。
- `sections/07-review-comments.tex`、`sections/08-department-comments.tex`：审核意见和院系意见。
- `main.tex`：表格尺寸、签名区、定密审批字段及其他排版细节。

普通正文段落之间留一空行；可使用 LaTeX 公式、引用和图表。正文的三个大框可以随长内容跨页；摘要、签名和行政表格的单元格会随内容增高，但过长时需自行缩短或调整留白高度，以免整张表超过纸张高度。

所有勾选框默认为空。选中时将对应的 `\square` 改为 `\boxtimes`。定密审批表默认附在末尾，如需隐藏，可在 `metadata.tex` 中将 `\showconfidentialformtrue` 改为 `\showconfidentialformfalse`。

## 字体与版式

保持 A4、黑白表格及原模板的宋体、黑体、仿宋字体角色。正文页边距为2.5厘米；封面及原 Word 中较宽的定密审批表单独设置。空模板按八页排版，填写内容后页数可能变化。

中文字体优先使用本机安装的 Windows 字体，缺少时回退到 TeX Live 自带的 Fandol 字体。若须使用与 Word 相同的字形，可把自己有权使用的 `simsun.ttc`、`simhei.ttf`、`simfang.ttf` 放到新建的 `fonts/` 目录。字体差异可能导致换行变化，转换版不保证与 Word 逐行完全一致。

工程只包含可编辑 LaTeX 源文件和从原 Word 提取的校名图片，没有将表格转为图片。原文件未填写的研究内容、审批意见和签名均保留为空白。
